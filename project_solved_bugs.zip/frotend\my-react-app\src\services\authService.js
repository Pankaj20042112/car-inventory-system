import API from './api';

export const login = async (username, password) => {
  const response = await API.post('/auth/login', { username, password });
  if (response.data.token) {
    localStorage.setItem('token', response.data.token);
    localStorage.setItem('user', JSON.stringify(response.data.user));
  }
  return response.data;
};

export const register = async (username, password, role = 'user', name, email, category) => {
  const response = await API.post('/auth/register', { username, password, role, name, email, category });
  return response.data;
};

export const logout = () => {
  localStorage.removeItem('token');
  localStorage.removeItem('user');
};

export const getCurrentUser = () => {
  const user = localStorage.getItem('user');
  return user ? JSON.parse(user) : null;
};

export const getProfile = async () => {
  const response = await API.get('/auth/me');
  return response.data;
};
